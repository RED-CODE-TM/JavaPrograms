-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2024 at 10:51 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrismart`
--

-- --------------------------------------------------------

--
-- Table structure for table `crophistory`
--

CREATE TABLE `crophistory` (
  `HistoryID` int(11) NOT NULL,
  `CropType` varchar(100) DEFAULT NULL,
  `PlantingDate` varchar(100) DEFAULT NULL,
  `HarvestYield` varchar(100) DEFAULT NULL,
  `Notes` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crophistory`
--

INSERT INTO `crophistory` (`HistoryID`, `CropType`, `PlantingDate`, `HarvestYield`, `Notes`) VALUES
(1, 'bodybuilding', 'jan', 'manual', 'hello world');

-- --------------------------------------------------------

--
-- Table structure for table `croprecommendations`
--

CREATE TABLE `croprecommendations` (
  `CropID` int(11) NOT NULL,
  `CropName` varchar(100) DEFAULT NULL,
  `PlantingSeason` varchar(100) DEFAULT NULL,
  `RecommendedPractices` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `croprecommendations`
--

INSERT INTO `croprecommendations` (`CropID`, `CropName`, `PlantingSeason`, `RecommendedPractices`) VALUES
(1, 'Wheat', 'Spring', 'Use balanced fertilization'),
(2, 'rice', 'Summer', 'Selling'),
(3, 'Cassava', 'Winter', 'Eat');

-- --------------------------------------------------------

--
-- Table structure for table `soilmoisturedata`
--

CREATE TABLE `soilmoisturedata` (
  `DataID` int(11) NOT NULL,
  `Timestamp` varchar(100) DEFAULT NULL,
  `MoistureLevel` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `soilmoisturedata`
--

INSERT INTO `soilmoisturedata` (`DataID`, `Timestamp`, `MoistureLevel`) VALUES
(1, 'December', 'First');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crophistory`
--
ALTER TABLE `crophistory`
  ADD PRIMARY KEY (`HistoryID`);

--
-- Indexes for table `croprecommendations`
--
ALTER TABLE `croprecommendations`
  ADD PRIMARY KEY (`CropID`);

--
-- Indexes for table `soilmoisturedata`
--
ALTER TABLE `soilmoisturedata`
  ADD PRIMARY KEY (`DataID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crophistory`
--
ALTER TABLE `crophistory`
  MODIFY `HistoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `croprecommendations`
--
ALTER TABLE `croprecommendations`
  MODIFY `CropID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `soilmoisturedata`
--
ALTER TABLE `soilmoisturedata`
  MODIFY `DataID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
